"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDownRight, Check, Pause, Play } from "lucide-react";
import AppleVrBackgroundStage from "@/components/AppleVrBackgroundStage";
import TopNav from "@/components/TopNav";
import Footer from "@/components/Footer";
import {
  HEADSET_ANNOTATIONS,
  IMPORTANCE_PILLARS,
  LIMITS_LIST,
  STRENGTHS_LIST,
  TOTAL_BG_FRAMES,
  USE_DOMAINS,
  calculateScrollFrame,
  getUseDomainById,
} from "@/lib/vrContent";

export default function SplitVrShowcase() {
  const mobileScrollRef = useRef<HTMLDivElement | null>(null);
  const splitContainerRef = useRef<HTMLDivElement | null>(null);
  const componentsSectionRef = useRef<HTMLElement | null>(null);

  const [isBgAnimating, setIsBgAnimating] = useState<boolean>(true);
  const [currentFrame, setCurrentFrame] = useState<number>(1);
  const [selectedDomainId, setSelectedDomainId] = useState<string>(
    USE_DOMAINS[0].id
  );
  const [activeAnnotationId, setActiveAnnotationId] = useState<string | null>(
    null
  );

  const activeDomain = getUseDomainById(selectedDomainId);

  // Sync the VR headset frame cleanly to scroll progress on both mobile (inner scroll pane)
  // and desktop/tablet (window scroll), reaching full disassembly (frame 193) at #composants.
  useEffect(() => {
    let rafId = 0;

    const updateFromScroll = () => {
      rafId = 0;
      const compEl = componentsSectionRef.current;
      const splitEl = splitContainerRef.current;
      const mobileScroller = mobileScrollRef.current;
      if (!splitEl) return;

      const isMobile = window.innerWidth < 768;

      if (isMobile && mobileScroller) {
        const scrollTop = mobileScroller.scrollTop;
        const maxScroll = Math.max(
          1,
          mobileScroller.scrollHeight - mobileScroller.clientHeight
        );
        const compTarget = compEl
          ? Math.max(1, Math.min(maxScroll, compEl.offsetTop - 24))
          : maxScroll;
        const progress = Math.max(0, Math.min(1, scrollTop / compTarget));
        setCurrentFrame(calculateScrollFrame(progress, TOTAL_BG_FRAMES));
        return;
      }

      const targetScrollEnd = compEl
        ? Math.max(1, compEl.offsetTop - window.innerHeight * 0.22)
        : Math.max(1, splitEl.offsetHeight - window.innerHeight);

      const progress = Math.max(
        0,
        Math.min(1, window.scrollY / targetScrollEnd)
      );
      setCurrentFrame(calculateScrollFrame(progress, TOTAL_BG_FRAMES));
    };

    const onScroll = () => {
      if (!rafId) {
        rafId = window.requestAnimationFrame(updateFromScroll);
      }
    };

    const mobileEl = mobileScrollRef.current;
    updateFromScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    mobileEl?.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      mobileEl?.removeEventListener("scroll", onScroll);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, []);

  const handleNavigateSection = useCallback((sectionId: string) => {
    const target = document.getElementById(sectionId);
    const mobileScroller = mobileScrollRef.current;
    if (!target) return;

    if (window.innerWidth < 768 && mobileScroller) {
      const top = Math.max(0, target.offsetTop - 16);
      mobileScroller.scrollTo({ top, behavior: "smooth" });
      return;
    }

    const desktopTop = Math.max(0, target.offsetTop - 84);
    window.scrollTo({ top: desktopTop, behavior: "smooth" });
  }, []);

  const handleJumpToExploded = useCallback(() => {
    handleNavigateSection("composants");
  }, [handleNavigateSection]);

  const handleResetTop = useCallback(() => {
    const mobileScroller = mobileScrollRef.current;
    if (window.innerWidth < 768 && mobileScroller) {
      mobileScroller.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <div className="relative h-[100dvh] flex flex-col overflow-hidden bg-black text-[#F4F6FA] md:block md:h-auto md:min-h-screen md:overflow-visible">
      <TopNav onNavigateSection={handleNavigateSection} />

      {/* Single responsive VR stage:
          - Mobile (< md): docked cleanly below header (shrink-0), never overlaps scrolling text
          - Desktop (md+): fixed Apple-style right background stage (41.5%..98.5%) */}
      <AppleVrBackgroundStage
        targetFrame={currentFrame}
        isAmbientAnimating={isBgAnimating}
        activeAnnotationId={activeAnnotationId}
        onSelectAnnotation={setActiveAnnotationId}
        onJumpToExploded={handleJumpToExploded}
        onResetTop={handleResetTop}
      />

      {/* Scrollable French academic narrative:
          - Mobile (< md): independent scroll pane strictly below the headset stage
          - Desktop (md+): window-scrolled left column (0..39%) */}
      <div
        ref={mobileScrollRef}
        className="relative z-10 flex-1 overflow-y-auto overscroll-contain md:overflow-visible md:pointer-events-none"
      >
        <main>
          <div
            ref={splitContainerRef}
            className="mx-auto max-w-7xl px-6 pt-6 pb-16 md:pt-12 md:pb-28"
          >
            <div className="pointer-events-auto w-full md:w-[39%] md:max-w-[445px] flex flex-col gap-16 md:gap-24">
              {/* 1. Introduction */}
              <section
                id="introduction"
                className="pt-1 md:min-h-[68vh] md:flex md:flex-col md:justify-center"
              >
                <h1
                  className="font-bold tracking-[-0.03em] text-white leading-[1.08]"
                  style={{ fontSize: "clamp(1.85rem, 3.3vw, 3rem)" }}
                >
                  La Réalité Virtuelle : importance et utilisations
                </h1>

                <p className="mt-5 text-base leading-[1.68] text-[#D4DAE4] max-w-[46ch]">
                  La réalité virtuelle (RV) est une technologie informatique qui
                  simule un environnement complet en trois dimensions. En
                  portant un casque dédié, l&apos;utilisateur est immergé dans un
                  espace numérique avec lequel il interagit en temps réel.
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-3.5">
                  <a
                    href="#importance"
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavigateSection("importance");
                    }}
                    className="inline-flex items-center gap-2 rounded-lg bg-sky-400 px-4 py-2.5 text-sm font-semibold text-slate-950 hover:bg-sky-300 transition-colors duration-150 whitespace-nowrap shrink-0 min-h-[42px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300 focus-visible:ring-offset-2 focus-visible:ring-offset-black"
                  >
                    <span>Découvrir l&apos;importance</span>
                    <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={() => setIsBgAnimating((prev) => !prev)}
                    aria-pressed={isBgAnimating}
                    className="inline-flex items-center gap-2 rounded-lg border border-white/[0.16] bg-[#0A0E16] px-3.5 py-2.5 text-xs font-medium text-[#D4DAE4] hover:border-white/[0.28] hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 min-h-[42px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400"
                  >
                    {isBgAnimating ? (
                      <>
                        <Pause
                          className="h-3.5 w-3.5 text-sky-400"
                          aria-hidden="true"
                        />
                        <span>Fond animé actif</span>
                      </>
                    ) : (
                      <>
                        <Play
                          className="h-3.5 w-3.5 text-sky-400"
                          aria-hidden="true"
                        />
                        <span>Activer le fond animé</span>
                      </>
                    )}
                  </button>
                </div>
              </section>

              {/* 2. Importance */}
              <section
                id="importance"
                className="border-t border-white/[0.12] pt-12 md:pt-14"
              >
                <h2 className="text-2xl font-semibold tracking-[-0.02em] text-white">
                  Pourquoi la réalité virtuelle est-elle importante ?
                </h2>
                <p className="mt-3 text-base leading-[1.68] text-[#9BA6B8]">
                  Aujourd&apos;hui, la réalité virtuelle dépasse le simple
                  divertissement. Elle répond à des besoins concrets de
                  formation, de sécurité et de compréhension scientifique.
                </p>

                <div className="mt-7 divide-y divide-white/[0.08] border-t border-white/[0.08]">
                  {IMPORTANCE_PILLARS.map((pillar) => (
                    <article key={pillar.id} className="py-5">
                      <h3 className="text-base font-semibold text-white">
                        {pillar.title}
                      </h3>
                      <p className="mt-2 text-sm leading-[1.68] text-[#D4DAE4]">
                        {pillar.summary}
                      </p>
                    </article>
                  ))}
                </div>
              </section>

              {/* 3. Domaines d'utilisation */}
              <section
                id="utilisations"
                className="border-t border-white/[0.12] pt-12 md:pt-14"
              >
                <h2 className="text-2xl font-semibold tracking-[-0.02em] text-white">
                  Où utilise-t-on la réalité virtuelle ?
                </h2>
                <p className="mt-3 text-base leading-[1.68] text-[#9BA6B8]">
                  Sélectionnez un secteur pour observer ses applications
                  concrètes et son apport principal.
                </p>

                <div
                  role="tablist"
                  aria-label="Domaines d'utilisation de la réalité virtuelle"
                  className="mt-6 flex flex-wrap gap-6 border-b border-white/[0.1]"
                >
                  {USE_DOMAINS.map((domain) => {
                    const isSelected = domain.id === activeDomain.id;
                    return (
                      <button
                        key={domain.id}
                        type="button"
                        role="tab"
                        aria-selected={isSelected}
                        onClick={() => setSelectedDomainId(domain.id)}
                        className={`relative pb-3 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm ${
                          isSelected
                            ? "text-white font-semibold"
                            : "text-[#9BA6B8] hover:text-white"
                        }`}
                      >
                        {domain.label}
                        {isSelected ? (
                          <span
                            aria-hidden="true"
                            className="absolute inset-x-0 -bottom-px h-0.5 bg-sky-400"
                          />
                        ) : null}
                      </button>
                    );
                  })}
                </div>

                <div
                  role="tabpanel"
                  aria-label={activeDomain.title}
                  className="mt-6"
                >
                  <h3 className="text-lg font-semibold text-white">
                    {activeDomain.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-[1.68] text-[#D4DAE4]">
                    {activeDomain.summary}
                  </p>

                  <ul className="mt-5 space-y-3">
                    {activeDomain.examples.map((example) => (
                      <li
                        key={example}
                        className="flex items-start gap-2.5 text-sm leading-[1.6] text-[#D4DAE4]"
                      >
                        <Check
                          className="mt-1 h-4 w-4 shrink-0 text-sky-400"
                          aria-hidden="true"
                        />
                        <span>{example}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 border-t border-white/[0.08] pt-4">
                    <p className="text-xs font-medium text-[#9BA6B8]">
                      Objectif principal
                    </p>
                    <p className="mt-1 text-sm font-medium text-sky-300">
                      {activeDomain.objective}
                    </p>
                  </div>
                </div>
              </section>

              {/* 4. Composants clés du casque & Synthèse finale (no duplicate image!) */}
              <section
                id="composants"
                ref={componentsSectionRef}
                className="border-t border-white/[0.12] pt-12 md:pt-14"
              >
                <h2 className="text-2xl font-semibold tracking-[-0.02em] text-white">
                  Les principaux composants du casque
                </h2>
                <p className="mt-3 text-base leading-[1.68] text-[#9BA6B8]">
                  En fin de défilement, le casque se démonte pour révéler ses
                  six éléments clés. Sélectionnez un composant pour mettre en
                  évidence sa ligne sur le schéma.
                </p>

                <div className="mt-6 divide-y divide-white/[0.08] border-y border-white/[0.08]">
                  {HEADSET_ANNOTATIONS.map((ann) => {
                    const isActive = activeAnnotationId === ann.id;
                    return (
                      <button
                        key={ann.id}
                        type="button"
                        onMouseEnter={() => setActiveAnnotationId(ann.id)}
                        onMouseLeave={() => setActiveAnnotationId(null)}
                        onClick={() => {
                          setActiveAnnotationId(isActive ? null : ann.id);
                          handleJumpToExploded();
                        }}
                        className={`w-full py-3.5 px-2 text-left transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 ${
                          isActive ? "bg-sky-500/[0.08]" : "hover:bg-white/[0.03]"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-3">
                          <span
                            className={`text-sm font-semibold transition-colors duration-150 ${
                              isActive ? "text-sky-300" : "text-white"
                            }`}
                          >
                            {ann.label}
                          </span>
                          <span
                            aria-hidden="true"
                            className={`h-1.5 w-1.5 rounded-full transition-colors duration-150 ${
                              isActive ? "bg-sky-400" : "bg-white/25"
                            }`}
                          />
                        </div>
                        <p className="mt-1 text-xs leading-[1.6] text-[#9BA6B8]">
                          {ann.description}
                        </p>
                      </button>
                    );
                  })}
                </div>

                {/* Forces & Limites */}
                <div
                  id="synthese"
                  className="mt-10 grid grid-cols-1 gap-8 border-t border-white/[0.12] pt-10 sm:grid-cols-2"
                >
                  <div>
                    <h3 className="text-base font-semibold text-white">
                      Forces majeures
                    </h3>
                    <ul className="mt-3 space-y-2.5 text-sm leading-[1.6] text-[#D4DAE4]">
                      {STRENGTHS_LIST.map((item) => (
                        <li key={item}>— {item}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-base font-semibold text-white">
                      Limites actuelles
                    </h3>
                    <ul className="mt-3 space-y-2.5 text-sm leading-[1.6] text-[#9BA6B8]">
                      {LIMITS_LIST.map((item) => (
                        <li key={item}>— {item}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-10 border-t border-white/[0.12] pt-8">
                  <h3 className="text-base font-semibold text-white">
                    Conclusion générale
                  </h3>
                  <p className="mt-2.5 text-sm leading-[1.68] text-[#D4DAE4]">
                    En résumé, la réalité virtuelle s&apos;impose comme un outil
                    scientifique, éducatif et professionnel de premier plan.
                    Utilisée de manière encadrée, elle complète
                    l&apos;enseignement traditionnel en offrant un espace
                    d&apos;expérimentation sûr et accessible.
                  </p>
                </div>
              </section>
            </div>
          </div>
        </main>

        <div className="pointer-events-auto">
          <Footer onNavigateSection={handleNavigateSection} />
        </div>
      </div>
    </div>
  );
}
