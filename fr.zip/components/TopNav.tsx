"use client";

import React from "react";

interface TopNavProps {
  onNavigateSection: (sectionId: string) => void;
}

export default function TopNav({ onNavigateSection }: TopNavProps) {
  const handleLinkClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    sectionId: string
  ) => {
    e.preventDefault();
    onNavigateSection(sectionId);
  };

  return (
    <header className="relative z-40 shrink-0 pointer-events-auto border-b border-white/[0.08] bg-black md:sticky md:top-0">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-6">
        <a
          href="#introduction"
          onClick={(e) => handleLinkClick(e, "introduction")}
          className="text-base font-semibold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 focus-visible:ring-offset-2 focus-visible:ring-offset-black rounded-sm"
        >
          Réalité Virtuelle
        </a>

        <nav
          aria-label="Navigation principale"
          className="hidden md:flex items-center gap-8 text-[13px] font-medium text-[#9BA6B8]"
        >
          <a
            href="#introduction"
            onClick={(e) => handleLinkClick(e, "introduction")}
            className="hover:text-white hover:underline transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
          >
            Introduction
          </a>
          <a
            href="#importance"
            onClick={(e) => handleLinkClick(e, "importance")}
            className="hover:text-white hover:underline transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
          >
            Importance
          </a>
          <a
            href="#utilisations"
            onClick={(e) => handleLinkClick(e, "utilisations")}
            className="hover:text-white hover:underline transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
          >
            Utilisations
          </a>
          <a
            href="#composants"
            onClick={(e) => handleLinkClick(e, "composants")}
            className="hover:text-white hover:underline transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
          >
            Composants
          </a>
        </nav>

        <div className="flex items-center shrink-0">
          <a
            href="#composants"
            onClick={(e) => handleLinkClick(e, "composants")}
            className="inline-flex items-center justify-center rounded-lg bg-sky-400 px-3.5 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-300 transition-colors duration-150 whitespace-nowrap shrink-0 min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300 focus-visible:ring-offset-2 focus-visible:ring-offset-black"
          >
            Vue éclatée
          </a>
        </div>
      </div>
    </header>
  );
}
