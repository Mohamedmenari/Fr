"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import HeadsetAnnotationsSvg from "@/components/HeadsetAnnotationsSvg";
import {
  HEADSET_ANNOTATIONS,
  TOTAL_BG_FRAMES,
  getBgFrameUrl,
  shouldShowAnnotations,
} from "@/lib/vrContent";

interface AppleVrBackgroundStageProps {
  targetFrame: number;
  isAmbientAnimating: boolean;
  activeAnnotationId: string | null;
  onSelectAnnotation: (id: string | null) => void;
  onJumpToExploded: () => void;
  onResetTop: () => void;
}

interface AmbientDot {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
}

export default function AppleVrBackgroundStage({
  targetFrame,
  isAmbientAnimating,
  activeAnnotationId,
  onSelectAnnotation,
  onJumpToExploded,
  onResetTop,
}: AppleVrBackgroundStageProps) {
  const ambientCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const headsetCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const imagesRef = useRef<Map<number, HTMLImageElement>>(new Map());
  const targetFrameRef = useRef<number>(targetFrame);
  const displayFrameRef = useRef<number>(targetFrame);
  const isAmbientRef = useRef<boolean>(isAmbientAnimating);

  const [loadedCount, setLoadedCount] = useState<number>(0);

  useEffect(() => {
    isAmbientRef.current = isAmbientAnimating;
  }, [isAmbientAnimating]);

  // Draw a specific WebP frame directly onto pure #000000 black
  const drawHeadsetFrame = useCallback((frameFloat: number) => {
    const canvas = headsetCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const targetIdx = Math.max(
      1,
      Math.min(TOTAL_BG_FRAMES, Math.round(frameFloat))
    );
    const map = imagesRef.current;
    let img = map.get(targetIdx);

    if (!img || !img.complete || img.naturalWidth === 0) {
      let bestDist = Infinity;
      let bestImg: HTMLImageElement | undefined;
      map.forEach((candidate, idx) => {
        if (candidate.complete && candidate.naturalWidth > 0) {
          const dist = Math.abs(idx - targetIdx);
          if (dist < bestDist) {
            bestDist = dist;
            bestImg = candidate;
          }
        }
      });
      img = bestImg;
    }

    if (!img || !img.complete || img.naturalWidth === 0) return;

    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    // Mask bottom-right source mark cleanly into pure black
    ctx.fillStyle = "#000000";
    ctx.fillRect(
      canvas.width * 0.84,
      canvas.height * 0.88,
      canvas.width * 0.16,
      canvas.height * 0.12
    );
  }, []);

  // Preload keyframes first (1, 25, ..., 193) then stream remaining frames
  useEffect(() => {
    let cancelled = false;
    const priorityFrames = [1, 25, 49, 73, 97, 121, 145, 169, 193];
    const remainingFrames: number[] = [];
    for (let i = 1; i <= TOTAL_BG_FRAMES; i++) {
      if (!priorityFrames.includes(i)) remainingFrames.push(i);
    }

    const loadSingle = (frameIdx: number) =>
      new Promise<void>((resolve) => {
        if (cancelled || imagesRef.current.has(frameIdx)) {
          resolve();
          return;
        }
        const img = new window.Image();
        img.decoding = "async";
        img.onload = () => {
          if (!cancelled) {
            imagesRef.current.set(frameIdx, img);
            setLoadedCount(imagesRef.current.size);
            if (
              Math.abs(frameIdx - Math.round(displayFrameRef.current)) <= 1 ||
              (frameIdx === 1 && Math.round(displayFrameRef.current) === 1)
            ) {
              drawHeadsetFrame(displayFrameRef.current);
            }
          }
          resolve();
        };
        img.onerror = () => resolve();
        img.src = getBgFrameUrl(frameIdx);
      });

    const preloadAll = async () => {
      await Promise.all(priorityFrames.map(loadSingle));
      if (!cancelled) {
        drawHeadsetFrame(displayFrameRef.current);
      }
      const batchSize = 10;
      for (let i = 0; i < remainingFrames.length; i += batchSize) {
        if (cancelled) break;
        await Promise.all(
          remainingFrames.slice(i, i + batchSize).map(loadSingle)
        );
      }
    };

    preloadAll();
    return () => {
      cancelled = true;
    };
  }, [drawHeadsetFrame]);

  // Smooth inertial frame interpolation (honors prefers-reduced-motion)
  useEffect(() => {
    targetFrameRef.current = targetFrame;
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reduced) {
      displayFrameRef.current = targetFrame;
      drawHeadsetFrame(targetFrame);
      return;
    }

    let rafId = 0;

    const tick = () => {
      const diff = targetFrameRef.current - displayFrameRef.current;
      if (Math.abs(diff) <= 0.15) {
        displayFrameRef.current = targetFrameRef.current;
        drawHeadsetFrame(displayFrameRef.current);
        rafId = 0;
        return;
      }

      displayFrameRef.current += diff * 0.28;
      drawHeadsetFrame(displayFrameRef.current);
      rafId = window.requestAnimationFrame(tick);
    };

    rafId = window.requestAnimationFrame(tick);
    return () => {
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, [targetFrame, drawHeadsetFrame]);

  // Subtle full-viewport pure-black studio halo + drifting spatial particles
  useEffect(() => {
    const canvas = ambientCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const prefersReducedMotion =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const dots: AmbientDot[] = Array.from({ length: 24 }, (_, idx) => ({
      x: ((idx * 89) % 100) / 100,
      y: ((idx * 61) % 100) / 100,
      vx: ((idx % 5) - 2) * 0.00016 || 0.00011,
      vy: ((idx % 3) - 1) * 0.00012 - 0.00008,
      radius: 0.9 + (idx % 3) * 0.5,
      alpha: 0.1 + (idx % 4) * 0.045,
    }));

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener("resize", resize);

    let rafId = 0;
    let timerId: number | null = null;
    const start = performance.now();

    const drawAmbient = (now: number) => {
      const w = canvas.width;
      const h = canvas.height;
      const t = (now - start) * 0.001;
      const scrollRatio =
        (targetFrameRef.current - 1) / Math.max(1, TOTAL_BG_FRAMES - 1);

      ctx.fillStyle = "#000000";
      ctx.fillRect(0, 0, w, h);

      const driftX =
        isAmbientRef.current && !prefersReducedMotion
          ? Math.sin(t * 0.35) * w * 0.02
          : 0;
      const driftY =
        isAmbientRef.current && !prefersReducedMotion
          ? Math.cos(t * 0.28) * h * 0.02
          : 0;

      const centerX = w >= 768 ? w * 0.7 + driftX : w * 0.5 + driftX;
      const centerY = w >= 768 ? h * 0.52 + driftY : h * 0.22 + driftY;
      const radius = Math.max(w, h) * (0.34 + scrollRatio * 0.06);

      const halo = ctx.createRadialGradient(
        centerX,
        centerY,
        radius * 0.03,
        centerX,
        centerY,
        radius
      );
      halo.addColorStop(0, "rgba(56, 189, 248, 0.13)");
      halo.addColorStop(0.45, "rgba(15, 38, 86, 0.06)");
      halo.addColorStop(1, "rgba(0, 0, 0, 0)");

      ctx.fillStyle = halo;
      ctx.fillRect(0, 0, w, h);

      for (const dot of dots) {
        if (isAmbientRef.current && !prefersReducedMotion) {
          dot.x = (dot.x + dot.vx + 1) % 1;
          dot.y = (dot.y + dot.vy + 1) % 1;
        }
        ctx.fillStyle = `rgba(186, 230, 253, ${dot.alpha})`;
        ctx.beginPath();
        ctx.arc(dot.x * w, dot.y * h, dot.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      if (isAmbientRef.current && !prefersReducedMotion) {
        timerId = window.setTimeout(() => {
          rafId = window.requestAnimationFrame(drawAmbient);
        }, 55);
      }
    };

    rafId = window.requestAnimationFrame(drawAmbient);

    return () => {
      window.removeEventListener("resize", resize);
      if (timerId !== null) window.clearTimeout(timerId);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, [isAmbientAnimating]);

  const annotationsVisible = shouldShowAnnotations(targetFrame);
  const progressPct = Math.round(
    ((targetFrame - 1) / (TOTAL_BG_FRAMES - 1)) * 100
  );

  const stageCaption =
    targetFrame < 49
      ? "Casque assemblé"
      : targetFrame < 110
      ? "Séparation du boîtier"
      : targetFrame < 165
      ? "Révélation optique interne"
      : "Vue éclatée et annotée";

  const activeDescription = annotationsVisible
    ? activeAnnotationId
      ? HEADSET_ANNOTATIONS.find((a) => a.id === activeAnnotationId)?.description
      : "Survolez une ligne ou choisissez un composant."
    : null;

  return (
    <>
      <div
        data-testid="ambient-vr-background"
        data-animating={String(isAmbientAnimating)}
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-black"
      >
        <canvas ref={ambientCanvasRef} className="block h-full w-full" />
      </div>

      {/* Single responsive stage:
          - Mobile (< md): normal flex item (shrink-0) strictly above the scrollable text pane (never overlaps text!)
          - Desktop (md+): fixed Apple-style right background stage strictly in 41.5%..98.5% at z-20 */}
      <div
        data-testid="headset-scroll-stage"
        data-frame={targetFrame}
        data-annotations-visible={String(annotationsVisible)}
        className="relative z-20 shrink-0 border-b border-white/[0.08] bg-black px-2 py-2 md:fixed md:left-[41.5%] md:right-[1.5vw] md:top-[52%] md:-translate-y-1/2 md:border-b-0 md:bg-transparent md:px-0 md:py-0"
      >
        <div
          className="relative mx-auto aspect-video w-full max-w-[360px] max-h-[30dvh] md:max-w-none md:max-h-none transition-transform duration-300 ease-out"
          style={{
            transform: `scale(${(0.98 + (progressPct / 100) * 0.025).toFixed(3)})`,
          }}
        >
          <canvas
            ref={headsetCanvasRef}
            width={1280}
            height={720}
            className="block h-full w-full object-contain"
            aria-label={`Animation du casque de réalité virtuelle au défilement — image ${targetFrame} sur ${TOTAL_BG_FRAMES}`}
          />

          <HeadsetAnnotationsSvg
            visible={annotationsVisible}
            activeAnnotationId={activeAnnotationId}
            onSelectAnnotation={onSelectAnnotation}
          />
        </div>

        {/* Minimal status line on both mobile (compact) and desktop */}
        <div className="mt-1.5 flex items-baseline justify-between gap-4 border-t border-white/[0.08] pt-2 px-2 md:mt-3 md:gap-6 md:pt-3">
          <div className="min-w-0">
            <p className="text-[11px] md:text-xs font-medium text-[#F4F6FA] truncate">
              {stageCaption}
            </p>
            {activeDescription ? (
              <p className="hidden md:block mt-0.5 text-xs text-[#9BA6B8] truncate">
                {activeDescription}
              </p>
            ) : null}
          </div>

          <div className="flex items-center gap-4 shrink-0">
            <span className="text-[11px] md:text-xs font-mono tabular-nums text-[#9BA6B8]">
              {loadedCount < TOTAL_BG_FRAMES
                ? `${Math.round((loadedCount / TOTAL_BG_FRAMES) * 100)}%`
                : `${String(targetFrame).padStart(3, "0")} / ${TOTAL_BG_FRAMES}`}
            </span>
            {!annotationsVisible ? (
              <button
                type="button"
                onClick={onJumpToExploded}
                className="text-[11px] md:text-xs font-medium text-sky-400 hover:text-sky-300 underline-offset-4 hover:underline transition-colors whitespace-nowrap"
              >
                Voir la vue éclatée
              </button>
            ) : (
              <button
                type="button"
                onClick={onResetTop}
                className="text-[11px] md:text-xs font-medium text-sky-400 hover:text-sky-300 underline-offset-4 hover:underline transition-colors whitespace-nowrap"
              >
                Revenir au début
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
