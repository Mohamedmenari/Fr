"use client";

import React from "react";
import { HEADSET_ANNOTATIONS } from "@/lib/vrContent";

interface HeadsetAnnotationsSvgProps {
  visible: boolean;
  activeAnnotationId: string | null;
  onSelectAnnotation: (id: string | null) => void;
}

export default function HeadsetAnnotationsSvg({
  visible,
  activeAnnotationId,
  onSelectAnnotation,
}: HeadsetAnnotationsSvgProps) {
  return (
    <svg
      viewBox="0 0 1000 562.5"
      className={`absolute inset-0 h-full w-full transition-opacity duration-300 ${
        visible
          ? "opacity-100 pointer-events-auto"
          : "opacity-0 pointer-events-none"
      }`}
      role="img"
      aria-label="Schéma annoté des principaux composants du casque de réalité virtuelle"
    >
      {HEADSET_ANNOTATIONS.map((ann) => {
        const isHighlighted = activeAnnotationId === ann.id;
        const isDimmed = activeAnnotationId !== null && !isHighlighted;
        const strokeColor = isHighlighted ? "#38BDF8" : "#CBD5E1";
        const lineWidth = isHighlighted ? 2.1 : 1.25;
        const textColor = isHighlighted
          ? "#7DD3FC"
          : isDimmed
          ? "#9BA6B8"
          : "#F8FAFC";

        // Straight technical leader line terminating cleanly at the text anchor
        const lineEndY = ann.labelY < 280 ? ann.labelY + 12 : ann.labelY - 19;

        return (
          <g
            key={ann.id}
            className="cursor-pointer"
            opacity={isDimmed ? 0.5 : 1}
            onMouseEnter={() => onSelectAnnotation(ann.id)}
            onMouseLeave={() => onSelectAnnotation(null)}
            onClick={() =>
              onSelectAnnotation(isHighlighted ? null : ann.id)
            }
          >
            <line
              x1={ann.dotX}
              y1={ann.dotY}
              x2={ann.labelX}
              y2={lineEndY}
              stroke={strokeColor}
              strokeWidth={lineWidth}
              strokeOpacity={isHighlighted ? 1 : 0.85}
            />

            {/* Precision target ring & core point */}
            <circle
              cx={ann.dotX}
              cy={ann.dotY}
              r={isHighlighted ? 8 : 5}
              fill="none"
              stroke={isHighlighted ? "#38BDF8" : "rgba(248, 250, 252, 0.45)"}
              strokeWidth="1"
            />
            <circle
              cx={ann.dotX}
              cy={ann.dotY}
              r={isHighlighted ? 3.8 : 2.8}
              fill={isHighlighted ? "#38BDF8" : "#F8FAFC"}
            />

            <text
              x={ann.labelX}
              y={ann.labelY}
              textAnchor={ann.anchor}
              fill={textColor}
              fontSize="18"
              fontWeight={isHighlighted ? "700" : "500"}
              fontFamily="var(--font-body), sans-serif"
              paintOrder="stroke"
              stroke="#000000"
              strokeWidth="6.5"
              strokeLinejoin="round"
            >
              {ann.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
