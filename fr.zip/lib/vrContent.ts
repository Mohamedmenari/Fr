export const TOTAL_BG_FRAMES = 193;

export function getBgFrameUrl(frameIndex: number): string {
  const clamped = Math.max(1, Math.min(TOTAL_BG_FRAMES, Math.round(frameIndex)));
  const padded = String(clamped).padStart(4, "0");
  return `/aivid/frames/frame_${padded}.webp`;
}

export function calculateScrollFrame(
  progress: number,
  totalFrames: number = TOTAL_BG_FRAMES
): number {
  const safeProgress = Number.isFinite(progress)
    ? Math.max(0, Math.min(1, progress))
    : 0;
  return Math.max(
    1,
    Math.min(totalFrames, Math.round(safeProgress * (totalFrames - 1)) + 1)
  );
}

export function shouldShowAnnotations(frame: number): boolean {
  return frame >= 165;
}

export interface ImportancePillar {
  id: string;
  number: string;
  title: string;
  summary: string;
}

export interface UseDomain {
  id: string;
  label: string;
  title: string;
  summary: string;
  examples: string[];
  objective: string;
  frame: number;
}

export interface HeadsetAnnotation {
  id: string;
  label: string;
  description: string;
  /** Target dot coordinates in viewBox 0..1000 x 0..562.5 (16:9) */
  dotX: number;
  dotY: number;
  /** Label anchor coordinates in viewBox 0..1000 x 0..562.5 */
  labelX: number;
  labelY: number;
  anchor: "start" | "middle" | "end";
}

export const HEADSET_ANNOTATIONS: HeadsetAnnotation[] = [
  {
    id: "visiere",
    label: "Visière frontale",
    description:
      "Coque protectrice légère intégrant les repères lumineux de suivi.",
    dotX: 150,
    dotY: 295,
    labelX: 150,
    labelY: 48,
    anchor: "middle",
  },
  {
    id: "cameras",
    label: "Caméras de suivi",
    description:
      "Capteurs optiques détectant les mouvements de la tête et des mains.",
    dotX: 388,
    dotY: 156,
    labelX: 388,
    labelY: 48,
    anchor: "middle",
  },
  {
    id: "arceau",
    label: "Arceau de maintien",
    description:
      "Structure ergonomique répartissant le poids du casque sur la tête.",
    dotX: 790,
    dotY: 118,
    labelX: 895,
    labelY: 48,
    anchor: "middle",
  },
  {
    id: "lentilles",
    label: "Lentilles optiques",
    description:
      "Système optique multi-éléments élargissant le champ de vision en 3D.",
    dotX: 412,
    dotY: 342,
    labelX: 225,
    labelY: 528,
    anchor: "middle",
  },
  {
    id: "ecrans",
    label: "Écrans micro-OLED",
    description:
      "Double dalle haute définition affichant une image distincte pour chaque œil.",
    dotX: 505,
    dotY: 278,
    labelX: 525,
    labelY: 528,
    anchor: "middle",
  },
  {
    id: "processeur",
    label: "Processeur spatial",
    description:
      "Carte électronique calculant l'affichage 3D et le suivi en temps réel.",
    dotX: 706,
    dotY: 292,
    labelX: 765,
    labelY: 528,
    anchor: "middle",
  },
];

export const IMPORTANCE_PILLARS: ImportancePillar[] = [
  {
    id: "securite",
    number: "01",
    title: "Apprendre et s'entraîner sans danger",
    summary:
      "La réalité virtuelle permet de répéter des gestes techniques difficiles — comme une intervention médicale, le pilotage ou la sécurité industrielle — sans exposer les personnes ni endommager le matériel réel.",
  },
  {
    id: "memorisation",
    number: "02",
    title: "Mieux comprendre par l'expérience",
    summary:
      "En plaçant l'apprenant au cœur d'une situation concrète en trois dimensions, l'immersion renforce l'attention et facilite la mémorisation par rapport à une lecture purement théorique.",
  },
  {
    id: "accessibilite",
    number: "03",
    title: "Réduire les coûts et les distances",
    summary:
      "Un établissement scolaire ou un centre de recherche peut simuler des équipements coûteux, des laboratoires ou des lieux éloignés sans devoir déplacer les étudiants ou acheter chaque appareil.",
  },
  {
    id: "visualisation",
    number: "04",
    title: "Rendre l'invisible observable",
    summary:
      "Elle offre la possibilité d'explorer des phénomènes impossibles à voir à l'œil nu, comme l'intérieur d'une cellule humaine, la structure d'une molécule ou un monument ancien reconstitué.",
  },
];

export const USE_DOMAINS: UseDomain[] = [
  {
    id: "education",
    label: "Éducation",
    title: "Éducation et formation professionnelle",
    summary:
      "Dans les écoles, les universités et les centres techniques, la réalité virtuelle complète les cours théoriques par des exercices pratiques immersifs.",
    examples: [
      "Visites virtuelles de sites historiques, géographiques ou de musées en classe.",
      "Travaux pratiques de chimie, de physique ou de mécanique sans risque d'accident.",
      "Entraînement à la prise de parole en public et à la maintenance technique.",
    ],
    objective: "Passer de l'observation passive à l'apprentissage actif.",
    frame: 49,
  },
  {
    id: "sante",
    label: "Médecine",
    title: "Médecine, chirurgie et rééducation",
    summary:
      "Les hôpitaux et les facultés de médecine emploient la réalité virtuelle pour former les soignants et accompagner les patients tout au long de leur parcours de soin.",
    examples: [
      "Simulation d'opérations chirurgicales en 3D avant d'intervenir sur un patient.",
      "Accompagnement psychologique pour traiter progressivement certaines phobies.",
      "Séances de rééducation motrice interactives et mesurables après un traumatisme.",
    ],
    objective: "Améliorer la précision des gestes médicaux et le confort du patient.",
    frame: 121,
  },
  {
    id: "industrie",
    label: "Architecture",
    title: "Architecture, ingénierie et industrie",
    summary:
      "Avant de lancer la construction d'un bâtiment ou la fabrication d'un produit, les équipes visualisent leurs plans numériques à l'échelle réelle.",
    examples: [
      "Visite d'un bâtiment futur pour vérifier les volumes, la lumière et l'ergonomie.",
      "Détection précoce des défauts techniques avant le début de la production.",
      "Réunions de travail à distance autour d'une même maquette en trois dimensions.",
    ],
    objective: "Limiter les erreurs de conception et optimiser le temps de fabrication.",
    frame: 145,
  },
  {
    id: "culture",
    label: "Culture",
    title: "Culture, recherche et patrimoine",
    summary:
      "Les institutions culturelles et les chercheurs utilisent la réalité virtuelle pour conserver, restaurer et partager le patrimoine mondial.",
    examples: [
      "Reconstitution fidèle de monuments fragiles ou disparus au fil du temps.",
      "Accès à distance aux collections de musées pour les personnes empêchées de voyager.",
      "Exploration interactive d'œuvres artistiques pour mieux comprendre leur histoire.",
    ],
    objective: "Préserver la mémoire collective et démocratiser l'accès à la culture.",
    frame: 193,
  },
];

export const STRENGTHS_LIST: string[] = [
  "Immersion visuelle et sonore qui capte durablement l'attention.",
  "Possibilité de recommencer un exercice autant de fois que nécessaire.",
  "Partage facile de scénarios pédagogiques entre plusieurs établissements.",
];

export const LIMITS_LIST: string[] = [
  "Coût encore important des casques performants et du développement logiciel.",
  "Fatigue visuelle ou inconfort passager (cinétose) lors d'usages prolongés.",
  "Nécessité d'un encadrement humain pour préserver le lien social.",
];

export function getUseDomainById(id: string): UseDomain {
  return USE_DOMAINS.find((item) => item.id === id) ?? USE_DOMAINS[0];
}
